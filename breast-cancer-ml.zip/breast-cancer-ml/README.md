# Breast Cancer Prediction with Machine Learning

A complete, reproducible ML project that compares four classifiers on the **Breast Cancer Wisconsin (Diagnostic)** dataset and saves the best one for making predictions.

> **Disclaimer:** This is an educational project, not a medical tool. Do not use it for real diagnosis.

## Highlights

- Compares **Logistic Regression, KNN, SVM and Random Forest**
- Uses **scikit-learn Pipelines** (scaling + model) to avoid data leakage
- **Stratified 5-fold cross-validation** plus a held-out test set
- Metrics: accuracy, precision, recall, F1, ROC AUC
- Auto-generated plots (model comparison, confusion matrix)
- Saved model + a CLI for predictions
- Unit tests with `pytest`

## Results

| Model               | CV Accuracy | Test Accuracy | Precision | Recall | F1     | ROC AUC |
|---------------------|-------------|---------------|-----------|--------|--------|---------|
| Logistic Regression | 0.9780      | 0.9825        | 0.9861    | 0.9861 | 0.9861 | 0.9954  |
| SVM                 | 0.9692      | 0.9825        | 0.9861    | 0.9861 | 0.9861 | 0.9950  |
| KNN                 | 0.9626      | 0.9561        | 0.9589    | 0.9722 | 0.9655 | 0.9788  |
| Random Forest       | 0.9626      | 0.9561        | 0.9589    | 0.9722 | 0.9655 | 0.9932  |

![Model comparison](reports/model_comparison.png)
![Confusion matrix](reports/confusion_matrix.png)

## Project Structure

```
breast-cancer-ml/
├── src/
│   ├── data.py        # load + split data
│   ├── models.py      # candidate model pipelines
│   ├── train.py       # compare, evaluate, plot, save best model
│   └── predict.py     # CLI for predictions
├── tests/
│   └── test_pipeline.py
├── models/            # saved model (generated)
├── reports/           # plots and results.csv (generated)
├── requirements.txt
├── LICENSE
└── README.md
```

## Getting Started

```bash
git clone https://github.com/<your-username>/breast-cancer-ml.git
cd breast-cancer-ml

python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### Train

```bash
python -m src.train
```

### Predict

```bash
python -m src.predict                      # demo on 5 dataset samples
python -m src.predict --csv my_data.csv    # your own CSV with the 30 feature columns
```

### Test

```bash
pytest
```

## Dataset

569 samples, 30 numeric features computed from digitized images of breast mass cell nuclei. Target: `0 = malignant`, `1 = benign`. Loaded directly from scikit-learn, so no download is needed.

## Ideas for Improvement

- Hyperparameter tuning with `GridSearchCV`
- Add XGBoost / LightGBM
- Explain predictions with SHAP
- Wrap the model in a Streamlit or FastAPI app

## License

MIT
